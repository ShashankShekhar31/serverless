const AWS = require('aws-sdk');
const ses = new AWS.SES();

module.exports.sendEmail = async (event) => {
  try {
    const { receiver_email, subject, body_text } = JSON.parse(event.body);

    const params = {
      Destination: {
        ToAddresses: [receiver_email],
      },
      Message: {
        Body: {
          Text: { Data: body_text },
        },
        Subject: { Data: subject },
      },
      Source: "your-email@example.com", // Replace with your verified SES email
    };

    await ses.sendEmail(params).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Email sent successfully" }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to send email" }),
    };
  }
};
